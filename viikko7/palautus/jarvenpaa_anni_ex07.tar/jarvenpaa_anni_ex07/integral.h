double simpson(double, double, double, int, int);
double f(double);
