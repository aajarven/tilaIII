double romberg(double (*f)(double), double, double, int);
double f1(double);
double f2(double);
