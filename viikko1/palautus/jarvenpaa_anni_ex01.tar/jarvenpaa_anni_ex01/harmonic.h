float harmonic(void);
float harmonic_bunch(int);
