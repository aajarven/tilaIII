void exp_funs(double);
void exp_funs_Taylor(double);
